package com.bharat.fetchrewards.domain.model

data class Reward(
    val id: Int,
    val listId: Int,
    val name: String?
)