package com.bharat.fetchrewards.data.model

data class RewardDTO(
    val id: Int,
    val listId: Int,
    val name: String?
)