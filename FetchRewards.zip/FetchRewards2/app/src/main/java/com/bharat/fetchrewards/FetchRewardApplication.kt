package com.bharat.fetchrewards

import android.app.Application
import dagger.hilt.InstallIn
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class FetchRewardApplication: Application()